import datetime
import random
from difflib import SequenceMatcher
import speech_recognition as sr
import pyttsx3

# Initialize the recognizer and text-to-speech engine
recognizer = sr.Recognizer()
tts_engine = pyttsx3.init()

# Predefined conversation data
conversation_data = {
    "hello": "Hello!",
    "how are you?": "I'm fine, thank you.",
    "what's your name?": "I'm Thor, Hrishi's virtual assistant.",
    "what can you do?": "I can help answer questions, provide information, and assist with various tasks.",
    "tell me a joke": "Why don't scientists trust atoms? Because they make up everything!",
    "how old are you?": "I don't have an age. I'm a computer program created by OpenAI.",
    "what's your favorite color?": "I don't have preferences, but I can tell you about different colors if you'd like.",
    "where are you from?": "I was developed by OpenAI, a research organization based in San Francisco.",
    "do you like music?": "I don't have feelings, but I can help you find information about music.",
    "what's your favorite food?": "I don't eat, but I can suggest some delicious recipes if you'd like.",
    "can you help me with math?": "Sure! What math problem are you working on?",
    "who is the president of the United States?": "As of my last update in 2023, the president is Kamala Harris.",
    "tell me a fun fact": "Did you know that honey never spoils? Archaeologists have found pots of honey in ancient Egyptian tombs that are over 3000 years old and still edible!",
    "how do I cook pasta?": "To cook pasta, boil water in a large pot, add a pinch of salt, then add the pasta. Cook according to the package instructions, usually around 8-12 minutes, until al dente. Drain and serve with your favorite sauce.",
    "what's the capital of France?": "The capital of France is Paris.",
    "how many continents are there?": "There are seven continents: Africa, Antarctica, Asia, Europe, North America, Australia, and South America.",
    "can you tell me a story?": "Once upon a time, in a kingdom far away, there lived a brave knight...",
    "what is 2 + 2?": "2 + 2 is 4.",
    "how do you spell 'accommodate'?": "A-C-C-O-M-M-O-D-A-T-E.",
    "what is the meaning of life?": "The meaning of life is a question that has been pondered for centuries. Different cultures and philosophies have different answers. Some find meaning in love, others in knowledge, or in helping others.",
    "who wrote 'Hamlet'?": "William Shakespeare wrote 'Hamlet'.",
    "what is photosynthesis?": "Photosynthesis is the process by which green plants and some other organisms use sunlight to synthesize foods with the help of chlorophyll. It converts carbon dioxide and water into glucose and oxygen.",
    "can you help me with my homework?": "Sure, I'd be happy to help! What subject is your homework in?",
    "what's your favorite movie?": "I don't watch movies, but I can tell you about popular movies and recommend some based on your preferences.",
    "what is the largest planet in our solar system?": "The largest planet in our solar system is Jupiter.",
    "how do you make a paper airplane?": "To make a simple paper airplane, take a sheet of paper, fold it in half lengthwise, then unfold. Fold the top two corners to the center crease, then fold the angled edges to the center. Fold the plane in half, then fold down the wings to the base. Your paper airplane is ready to fly!",
    "who discovered America?": "Christopher Columbus is often credited with discovering America in 1492, although there were already indigenous peoples living there and Norse explorers had reached North America earlier.",
    "what is AI?": "AI, or artificial intelligence, refers to the simulation of human intelligence in machines that are programmed to think and learn like humans.",
    "what's the tallest mountain in the world?": "Mount Everest is the tallest mountain above sea level, reaching approximately 8,848 meters (29,029 feet).",
    "how do you say 'hello' in Spanish?": "Hello in Spanish is 'Hola'.",
    "what's the square root of 144?": "The square root of 144 is 12.",
    "tell me about the Great Wall of China": "The Great Wall of China is a series of fortifications made of stone, brick, tamped earth, wood, and other materials. It was built along the northern borders of China to protect against invasions and raids by nomadic groups.",
    "who painted the Mona Lisa?": "Leonardo da Vinci painted the Mona Lisa, one of the most famous paintings in the world.",
    "what's the deepest ocean in the world?": "The deepest ocean in the world is the Pacific Ocean, particularly the Mariana Trench, which reaches a depth of about 10,994 meters (36,070 feet).",
    "what's your favorite book?": "I don't read books, but I can recommend some popular books if you're interested.",
    "who invented the telephone?": "Alexander Graham Bell is credited with inventing the telephone.",
    "what's the speed of light?": "The speed of light in a vacuum is approximately 299,792,458 meters per second."
}

# Function to compute similarity between two strings
def similarity(a, b):
    return SequenceMatcher(None, a, b).ratio()

# Function to get dynamic response
def get_dynamic_response(user_input):
    if "time" in user_input.lower():
        return f"The current time is {datetime.datetime.now().strftime('%H:%M:%S')}."
    elif "weather" in user_input.lower():
        # Mock response for weather; this can be enhanced with an API call
        return "The weather is sunny with a chance of rain later today."
    elif "math" in user_input.lower() or any(char.isdigit() for char in user_input):
        try:
            result = eval(user_input)
            return f"The result of your math problem is {result}."
        except:
            return "I'm not sure how to solve that math problem. Could you please provide more details?"
    else:
        return None

# Function to retrieve response based on user input
def get_response(user_input):
    max_similarity = 0
    best_response = "I don't understand that."

    for key in conversation_data:
        sim_score = similarity(user_input.lower(), key.lower())
        if sim_score > max_similarity:
            max_similarity = sim_score
            best_response = conversation_data[key]

    # Set threshold for similarity (80%)
    if max_similarity >= 0.8:
        return best_response
    else:
        dynamic_response = get_dynamic_response(user_input)
        if dynamic_response:
            return dynamic_response
        return "I don't understand that."

# Function to speak text
def speak_text(text):
    tts_engine.say(text)
    tts_engine.runAndWait()

# Function to listen to user's speech
def listen_to_speech():
    with sr.Microphone() as source:
        print("Listening...")
        recognizer.adjust_for_ambient_noise(source)
        audio = recognizer.listen(source)
        try:
            print("Recognizing...")
            user_input = recognizer.recognize_google(audio)
            print(f"You: {user_input}")
            return user_input
        except sr.UnknownValueError:
            return "I couldn't understand what you said. Please try again."
        except sr.RequestError:
            return "Sorry, my speech service is down."

# Interaction loop with the user
speak_text("Hello! I'm a simple bot. Let's chat. Say 'exit' to end the conversation.")

while True:
    user_input = listen_to_speech()
    
    if user_input.lower() == 'exit':
        speak_text("Goodbye!")
        break

    # Get bot response based on user input
    bot_response = get_response(user_input)
    print(f"Bot: {bot_response}")
    speak_text(bot_response)