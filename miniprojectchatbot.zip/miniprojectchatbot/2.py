def triangle_type(a, b, c):
    if a + b <= c or a + c <= b or b + c <= a:
        return "These values do not form a triangle."
    elif a == b == c:
        return "Equilateral triangle"
    elif a == b or a == c or b == c:
        return "Isosceles triangle"
    else:
        return "Scalene triangle"

a = int(input("Enter the length of side a (1-10): "))
b = int(input("Enter the length of side b (1-10): "))
c = int(input("Enter the length of side c (1-10): "))

if 1 <= a <= 10 and 1 <= b <= 10 and 1 <= c <= 10:
    print(triangle_type(a, b, c))
else:
    print("Side lengths must be between 1 and 10.")