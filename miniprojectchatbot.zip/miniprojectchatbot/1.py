# Define prices
lock_price = 45
stock_price = 30
barrel_price = 25

# Input the number of locks, stocks, and barrels
locks = int(input("Enter number of locks: "))
stocks = int(input("Enter number of stocks: "))
barrels = int(input("Enter number of barrels: "))

# Validate inputs and print specific error messages if out of range
if not (1 <= locks <= 70):
    print("Error: The number of locks must be between 1 and 70.")
if not (1 <= stocks <= 80):
    print("Error: The number of stocks must be between 1 and 80.")
if not (1 <= barrels <= 90):
    print("Error: The number of barrels must be between 1 and 90.")

# Calculate total sales only if all inputs are valid
if 1 <= locks <= 70 and 1 <= stocks <= 80 and 1 <= barrels <= 90:
    sales = lock_price * locks + stock_price * stocks + barrel_price * barrels
    print(f"Total Sales = ${sales}")

    # Calculate commission based on sales
    if sales > 1800:
        commission = 0.10 * 1000 + 0.15 * 800 + 0.20 * (sales - 1800)
    elif sales > 1000:
        commission = 0.10 * 1000 + 0.15 * (sales - 1000)
    else:
        commission = 0.10 * sales

    print(f"Commission = ${commission}")
else:
    print("One or more inputs are out of range.")
